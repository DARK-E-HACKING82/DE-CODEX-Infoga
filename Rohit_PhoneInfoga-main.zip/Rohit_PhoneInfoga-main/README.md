# Rohit_PhoneInfoga
You can easily install PhoneInfoga with the help of this repository.

Install PhoneInfoga in Termux :-

Download Termux from Play Store :-
Link :- https://play.google.com/store/apps/details?id=com.termux

Then type command in Termux :-

apt update && apt upgrade -y

pkg install git -y

git clone https://github.com/avengerrohit/Rohit_PhoneInfoga

cd Rohit_PhoneInfoga/

chmod +x *

sh Rohit_PhoneInfoga

cd PhoneInfoga

python3 phoneinfoga.py -n +(phone number with country code)

Now you are good to go...
